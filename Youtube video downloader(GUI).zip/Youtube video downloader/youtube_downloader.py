import tkinter as tk
from tkinter import messagebox, filedialog
import yt_dlp as youtube_dl

def download_video():
    try:
        url = url_entry.get().strip()
        if not url:
            messagebox.showerror("Error", "Please enter a YouTube video URL")
            return

        save_path = filedialog.askdirectory()
        if not save_path:
            messagebox.showerror("Error", "Please select a directory to save the video")
            return

        selected_resolution = resolution_var.get()

        ydl_opts = {
            'format': f'bestvideo[height={selected_resolution}]+bestaudio/best',  
            'outtmpl': f'{save_path}/%(title)s.%(ext)s',
            'noplaylist': True, 
            'merge_output_format': 'mp4', 
        }

        try:
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                info_dict = ydl.extract_info(url, download=True)
                messagebox.showinfo("Success", f"Video downloaded successfully in {selected_resolution}p to {save_path}")
        
        except youtube_dl.DownloadError as e:
            if 'Requested format is not available' in str(e):
                # If the requested format is not available, It download the best available format.
                ydl_opts['format'] = 'bestvideo+bestaudio/best'
                with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                    info_dict = ydl.extract_info(url, download=True)
                    max_resolution = max(f['height'] for f in info_dict['formats'] if f['vcodec'] != 'none')
                    messagebox.showinfo(
                        "Notice",
                        f"The selected resolution ({selected_resolution}p) was not available. "
                        f"The video was downloaded in its highest available resolution ({max_resolution}p)."
                    )
            else:
                raise

    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}")

def create_gui():
    root = tk.Tk()
    root.title("YouTube Video Downloader")

    global url_entry, resolution_var

    tk.Label(root, text="YouTube URL:").pack(pady=10)
    url_entry = tk.Entry(root, width=50)
    url_entry.pack(padx=20, pady=5)

    tk.Label(root, text="Select Resolution:").pack(pady=5)
    resolution_var = tk.StringVar(value="360")
    resolutions = [
        ("144p", "144"),
        ("240p", "240"),
        ("360p", "360"),
        ("480p", "480"),
        ("720p", "720"),
        ("1080p", "1080"),
        ("1440p", "1440"),
        ("4K", "2160"),
    ]
    for text, value in resolutions:
        tk.Radiobutton(root, text=text, variable=resolution_var, value=value).pack(anchor="w")

    tk.Button(root, text="Download", command=download_video).pack(pady=20)

    root.geometry("400x400")
    root.mainloop()

if __name__ == "__main__":
    create_gui() 